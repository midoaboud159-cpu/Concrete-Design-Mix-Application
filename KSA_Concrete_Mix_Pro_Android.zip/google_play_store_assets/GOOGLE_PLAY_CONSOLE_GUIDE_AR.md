# دليل رفع تطبيق (تصميم الخلطات الخرسانية KSA) على متجر Google Play خطوة بخطوة

يحتوي هذا المجلد على مشروع **Android Studio** الكامل الجاهز لبناء ملف الحزمة الرسمي (`.aab` - Android App Bundle) ورفعه على حساب المطور في **Google Play Console**.

---

## أولاً: محتويات الحزمة
1. **ملفات مشروع الأندرويد الكاملة (`app/`, `build.gradle.kts`, `settings.gradle.kts`):**
   - مبرمجة بلغة **Kotlin** وتستهدف **API 35 (Android 15)** وهو الشرط الإلزامي لقبول التطبيقات الجديدة في متجر Google Play.
   - تحتوي على جسر طباعة أندرويد أصلي (`AndroidNativeBridge`) لحفظ تقارير اعتماد الخلطة كملف **PDF** مباشرة من الهاتف.
2. **حقيبة متجر جوجل بلاي (`google_play_store_assets/`):**
   - `icon_512x512.png`: أيقونة المتجر عالية الدقة بمقاس `512×512` بكسل.
   - `feature_graphic_1024x500.png`: صورة البانر الترويجي للمتجر بمقاس `1024×500` بكسل.
   - `privacy_policy.html`: صفحة سياسة الخصوصية الجاهزة (مطلوبة في Google Play Console).

---

## ثانياً: خطوات استخراج ملف `.aab` الموقع من Android Studio
1. افتح برنامج **Android Studio** واختر **Open** ثم اختر مجلد `KSA_Concrete_Mix_Pro_Android`.
2. انتظر ثواني حتى يكتمل تزامن **Gradle Sync**.
3. من القائمة العلوية اختر:
   `Build > Generate Signed App Bundle / APK...`
4. اختر **Android App Bundle** ثم اضغط **Next**.
5. تحت حقل **Key store path** اضغط على **Create new...**:
   - اختر مكان حفظ ملف المفتاح (مثلاً `release-key.jks`).
   - اكتب كلمة مرور للمفتاح واسم الـ Alias (`ksa_concrete_mix_key`) وبياناتك، ثم اضغط **OK**.
6. اختر `release` واضغط **Create**.
7. ستحصل على الملف النهائي في المسار:
   `app/release/app-release.aab`

---

## ثالثاً: خطوات الرفع على Google Play Console
1. ادخل إلى [Google Play Console](https://play.google.com/console) واضغط **إنشاء تطبيق (Create app)**:
   - **اسم التطبيق:** `تصميم الخلطات الخرسانية KSA`
   - **اللغة الافتراضية:** العربية (`Arabic`)
   - **التطبيق أو اللعبة:** تطبيق (`App`)
   - **مجاني أو مدفوع:** حسب رغبتك
2. في قسم **محتوى التطبيق (App content)**:
   - **سياسة الخصوصية:** ارفع ملف `privacy_policy.html` على GitHub Pages أو Google Sites وضع الرابط.
   - **أمان البيانات (Data safety):** اختر *"لا، لا يجمع تطبيقي أو يشارك أيّاً من أنواع بيانات المستخدمين المطلوبة"*.
   - **الإعلانات (Ads):** اختر *"لا، لا يحتوي تطبيقي على إعلانات"*.
   - **تقييم المحتوى (Content rating):** اختر فئة *Reference, News, or Educational / Utility* وأجب بـ *"لا"* على جميع الأسئلة.
3. في قسم **الإصدار (Production / Closed Testing)**:
   - ارفع ملف `app-release.aab` الذي استخرجته من Android Studio.
