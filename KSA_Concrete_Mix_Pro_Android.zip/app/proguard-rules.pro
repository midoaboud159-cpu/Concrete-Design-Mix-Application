# Keep JavascriptInterface methods for WebView Native Print & Share Bridge
-keepattributes *Annotation*
-keepattributes JavascriptInterface
-keepclassmembers class sa.ksa.concretemixpro.MainActivity$AndroidNativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
