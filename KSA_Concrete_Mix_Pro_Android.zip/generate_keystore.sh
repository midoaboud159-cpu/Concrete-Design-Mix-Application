#!/usr/bin/env bash
# توليد مفتاح توقيع رسمي لرفع التطبيق على متجر Google Play
keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias ksa_concrete_mix_key
echo "تم إنشاء مفتاح التوقيع release-key.jks بنجاح!"
